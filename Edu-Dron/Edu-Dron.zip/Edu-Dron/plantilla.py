from api.dron import Dron

# crear el dron
midron = Dron()

# despegar el dron
midron.despegar()

# subir el dron un tramo
midron.subir()

# moverse a la derecha un tramo
midron.derecha()

# moverse a la izquierda durante 3 seg.
midron.izquierda()

# moverse adelante durante 3 seg.
midron.adelante()

# moverse atrás durante 3 seg.
midron.atras()

# girar el dron sobre su eje 90º a la derecha  
midron.giroderecha()

# girar el dron sobre su eje 90º a la izquierda  
midron.giroizquierda()


# aterrizar el dron
midron.aterrizar()






